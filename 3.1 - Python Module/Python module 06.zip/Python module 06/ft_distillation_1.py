import alchemy

if __name__ == "__main__":
    print("=== Distillation 1 ===")
    print("Using: 'import alchemy' structure to access potions")
    print(f"Testing strenght_potion: {alchemy.strength_potions()}")
    print(f"Testing heal alias: {alchemy.heal()}")
